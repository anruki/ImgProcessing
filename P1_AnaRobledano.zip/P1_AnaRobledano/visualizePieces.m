function visualizePieces(num_pieces,stats,board)
    imshow(board);
    hold on; 
    
    % Iterar a través de cada región para plotear los centroides y los nombres de las piezas
    for k = 1:num_pieces
            % Marcar el centroide
            plot(stats(k).Centroid(1), stats(k).Centroid(2), 'r.', 'MarkerSize', 4);
            
            text(stats(k).Centroid(1), stats(k).Centroid(2)-35, stats(k).Pieza, ...
                 'Color', 'blue', 'FontWeight', 'bold', ...
                 'FontSize', 6, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
    end
        
    hold off; 
    return
