function [stats, labeled_image, num_pieces] = pieceClassifier(brush,board)
    % imagen -> grises -> binarización -> apertura
    gray_board = im2gray(board);
    bin_board= ~imbinarize(gray_board,0.4);    
    filled_board = imfill(bin_board,"holes");
    close_board = imclose(filled_board,brush);

    % Etiquetado y análisis de regiones
    [labeled_image, num_pieces] = bwlabel(close_board);

    % Obtener las propiedades de las regiones
    stats = regionprops(labeled_image, 'Area', 'Centroid');

    % Inicializar la celda para almacenar los nombres de las piezas
    pieceNames = cell(num_pieces, 1); % Preallocar espacio para los nombres de las piezas

    % Asignar el tipo de pieza basado en el área
    for k = 1:num_pieces
        area = stats(k).Area; % Obtener el área de la región actual
        
        % Determinar el tipo de pieza según el área
        if area >= 1000 && area <= 1800
            pieceNames{k} = 'Peón';
        elseif area >= 2300 && area <= 2575
            pieceNames{k} = 'Alfil';
        elseif area >= 2576 && area <= 2800
            pieceNames{k} = 'Torre';
        elseif area >= 2801 && area <= 3050
            pieceNames{k} = 'Caballo';
        elseif area >= 3200 && area <= 3400
            pieceNames{k} = 'Reina';
        elseif area >= 3500 && area <= 3700
            pieceNames{k} = 'Rey';
        else
            pieceNames{k} = 'desconocido'; % Para áreas que no coinciden con ningún tipo
        end
    end

    % Añadir la columna 'Pieza' a la estructura stats
    for k = 1:num_pieces
        stats(k).Pieza = pieceNames{k}; % Añadir el nombre de la pieza
    end

    return
end
